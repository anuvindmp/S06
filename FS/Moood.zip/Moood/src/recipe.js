let dropdown;

window.onload = function() {
    dropdown = document.getElementById('dropdown');
    dropdown.style.display = "none";
};

function drop() {
    dropdown.style.display = "block";
}

function drop1(){
    dropdown.style.display = "none";
    
}